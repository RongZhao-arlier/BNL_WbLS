# WATER_ABS_LENGTH
Water Attenuation Length model from dyb-doc-992 used in Daya Bay
